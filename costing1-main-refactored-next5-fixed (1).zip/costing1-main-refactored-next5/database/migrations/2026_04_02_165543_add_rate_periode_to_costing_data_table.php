<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('costing_data', function (Blueprint $table) {
                $table->string('rate_periode')->nullable()->after('lme_rate');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('costing_data', function (Blueprint $table) {
                $table->dropColumn('rate_periode');
        });
    }
};
